# TidyViz

A Python package for survey data cleaning and visualization pipelines.

## Overview

TidyViz streamlines survey data analysis by providing specialized tools for:
- **Data Cleaning**: Handle common survey data issues like reshaping, validation, recoding, and outlier detection
- **Visualization**: Create survey-specific plots for categorical data, Likert scales, and distributions
- **Pipeline**: Chain operations together for reproducible workflows

## Installation

```bash
pip install tidyviz
```

For development:
```bash
pip install tidyviz[dev]
```

## Quick Start

```python
import pandas as pd
import tidyviz as tp

# Load your survey data
df = pd.read_csv('survey_data.csv')

# Expand multiple choice responses
df_expanded = tp.tidy.expand_multiple_choice(df, 'favorite_colors', sep=',')

# Validate response ranges
valid_df = tp.tidy.check_response_range(df, 'satisfaction', min_val=1, max_val=5)

# Create visualization
tp.viz.plot_single_choice(df, 'preferred_method', title='Preferred Contact Method')
```

## Features

### Cleaning Module

- **reshape.py**: Wide-to-long and long-to-wide conversions for survey data
- **validate.py**: Response validation and missing data pattern detection
- **recode.py**: Recode responses and handle "Other" text fields
- **outliers.py**: Detect and handle outliers in rating scales

### Visualization Module

- **categorical.py**: Bar charts for single and multiple choice questions
- **scales.py**: Likert scale and rating visualizations
- **distributions.py**: Response distributions and completion rates
- **themes.py**: Survey-appropriate styling

### Pipeline Module

- **chain.py**: Chain cleaning and visualization operations for reproducible workflows

## Examples

See the `examples/` directory for detailed usage examples:
- `basic_cleaning.py`: Data cleaning workflows
- `basic_viz.py`: Visualization examples
- `full_pipeline.py`: End-to-end pipeline demonstration

## Documentation

For full API documentation, visit [our documentation site](https://github.com/yourusername/tidyviz).

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

MIT License - see LICENSE file for details.

## Citation

If you use TidyViz in your research, please cite:

```
@software{tidyviz,
  author = {Your Name},
  title = {TidyViz: Survey Data Pipeline for Python},
  year = {2025},
  url = {https://github.com/yourusername/tidyviz}
}
```
